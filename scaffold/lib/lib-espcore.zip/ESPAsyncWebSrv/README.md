# ESPAsyncWebServer 

Async HTTP and WebSocket Server for ESP8266 Arduino

For ESP8266 it requires [ESPAsyncTCP](https://github.com/dvarrel/ESPAsyncTCP)
To use this library you might need to have the latest git versions of [ESP8266](https://github.com/esp8266/Arduino) Arduino Core

For ESP32 it requires [AsyncTCP](https://github.com/dvarrel/AsyncTCP) to work
To use this library you might need to have the latest git versions of [ESP32](https://github.com/espressif/arduino-esp32) Arduino Core

